package com.rashmi.qdevproject.pojo;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Book {

	@Id
	private int bookid;
	
	@Column
	private String book_title;
	
	@Column
	private String book_description;
	
	@Column
	private String author_name;
	
	@Column
	private Date release_date;

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getBook_title() {
		return book_title;
	}

	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}

	public String getBook_description() {
		return book_description;
	}

	public void setBook_description(String book_description) {
		this.book_description = book_description;
	}

	public String getAuthor_name() {
		return author_name;
	}

	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}

	public Date getRelease_date() {
		return release_date;
	}

	public void setRelease_date(Date release_date) {
		this.release_date = release_date;
	}

	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", book_title=" + book_title + ", book_description=" + book_description
				+ ", author_name=" + author_name + ", release_date=" + release_date + "]";
	}
	
	
	
	
	
	
}
