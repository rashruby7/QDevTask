package com.rashmi.qdevproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.rashmi.qdevproject.pojo.Book;
import com.rashmi.qdevproject.service.BookService;

@Controller

public class BookController {

	
	@Autowired
	private BookService bs;
	//to add_book.html page data
	
	@RequestMapping(path="/addbook")
	public String show_Add_Book_Page_Controller(Model m)
	{
		Book B=new Book();
		m.addAttribute("boo",B);
		return "add_book";
	}
	
	//open index.html as a home
	@RequestMapping(path="/")
	public String show_index_page_Controller(Model m)
	{
		List<Book> l=bs.getAllBooks();
	     m.addAttribute("b1",l);
		return "index";
	}
	
	//to add data in db
	@RequestMapping(path="/save",method=RequestMethod.GET)
	public String insert_Controller(@ModelAttribute("boo") Book B)
	{
		bs.save(B);
		return "redirect:/";
	}
	
	@RequestMapping(path="/edit/{id}")
	public ModelAndView showDetailsToEdit(@PathVariable(name="id")int id)
	{
		ModelAndView mav=new ModelAndView("add_edit");
		Book B=bs.getBook(id);
		mav.addObject("boo",B);
		return mav;
	}
	
	@RequestMapping(path="/delete/{id}")
	public String deleteController(@PathVariable(name="id")int id)
	{
		bs.delete(id);
		return "redirect:/";
	}
	
	
	
	
	
}
