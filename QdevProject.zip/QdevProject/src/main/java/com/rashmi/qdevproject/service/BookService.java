package com.rashmi.qdevproject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.rashmi.qdevproject.pojo.Book;
import com.rashmi.qdevproject.repository.BookRepository;

@Service
@Transactional
public class BookService {
	
	@Autowired
	private BookRepository br;
	
	public void save(Book B)
	{
		br.save(B);//save all from JpaRepositiory
	}
	
	public List<Book> getAllBooks()
	{
		List<Book> l=br.findAll();
		for(Book B:l)
			System.out.println(B);
		return br.findAll();//findall from Jparepository
	}
	
	//edit
	public Book getBook(int id)
	{
		return br.getById(id);
	}
	
	//delete
	public void delete(int id)
	{
		br.deleteById(id);
	}

}
