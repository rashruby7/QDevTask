package com.rashmi.qdevproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QdevProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QdevProjectApplication.class, args);
	}

}
